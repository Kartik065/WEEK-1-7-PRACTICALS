var registerForm = new Vue({
                              el: '#app',
                              data: {
                                errors: [],
                                name: '',
                                email: '',
                                password: '',
                                confirmPassword: '',
                                tittle: 'Registration Form',
                                role: '',
                                lang: [],
                                image: './assets/images/thumbsup.jpg',
                                options: [
                                  { designation: 'Engineer', value: 'Programmer' },
                                  { designation: 'Web Designer', value: 'Designer' },
                                  { designation: 'Web Developer', value: 'Developer' }
                                ]
                              },
                            
                              methods: {
                                validateForm: function (e) {
                                  this.errors = [];
                            
                                  //this.userError = this.name.length > 0 ? '' : 'user_name cant be blank'
                            
                                  if (!this.name) {
                                    this.errors.push('Username can not be blank');
                                  }
                                  if (!this.email) {
                                    this.errors.push('Email can not be blank');
                                  }
                                  else if (!this.validateEmail(this.email)) {
                                    this.errors.push('Please Enter A valid Email');
                                  }
                                  if (!this.password) {
                                    this.errors.push('Password can not be blank');
                                  }
                                  else if (!this.validatePassword(this.password)) {
                                    this.errors.push('Password must be 8 character long');
                                  }
                            
                                  if (!this.confirmPassword) {
                                    this.errors.push('Confirm Password can not be blank');
                                  }
                                  else if (!(this.password === this.confirmPassword)) {
                                    this.errors.push('Confirm Password Not Matched');
                                  }
                            
                                  if (!this.errors.length) {
                                    return true;
                                  }
                                  e.preventDefault();
                                },
                                validateEmail: function (email) {
                                  var emailregEx = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
                                  return emailregEx.test(email);
                                },
                                validatePassword: function (password) {
                                  var passregEx = /^[A-Za-z0-9]\w{7,15}$/;
                                  return passregEx.test(password);
                                }
                              }
                            })