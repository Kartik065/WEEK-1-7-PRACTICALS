let form = document.querySelector('#registration');
form.addEventListener('submit', function (event) {
    event.preventDefault();
    ValidateForm();
});

function ValidateForm() {
    checkUser();
    checkEmail();
    checkPassword();
    checkConfirmPassword();
}

function checkUser() {
    let userName = document.querySelector('#username');
    let userMessage = document.querySelector('#usermsg');
    let regEx = /^[a-zA-Z0-9]\w{3,9}$/;

    if (regEx.test(userName.value)) {
        formValidate(userName, userMessage);
    }
    else {
        formInValidate(userName, userMessage);
    }
};


function checkEmail() {
    let email = document.querySelector('#email');
    let emailMessage = document.querySelector('#emailmsg');
    let regEx = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

    if (regEx.test(email.value)) {
        formValidate(email, emailMessage);
    }
    else {
        formInValidate(email, emailMessage);
    }
};


function checkPassword() {
    let password = document.querySelector('#password');
    let passwordMessage = document.querySelector('#passmsg');
    let regEx = /^[A-Za-z0-9]\w{7,15}$/;
    if (regEx.test(password.value)) {
        formValidate(password, passwordMessage);
    }
    else {
        formInValidate(password, passwordMessage);
    }
};

function checkConfirmPassword() {
    let password = document.querySelector('#password');
    let cpassword = document.querySelector('#cpassword');
    let cpasswordMessage = document.querySelector('#cpassmsg');
    let regEx = /^[A-Za-z0-9]\w{7,15}$/;
    if (regEx.test(cpassword.value) && (password.value === cpassword.value)) {
        formValidate(cpassword, cpasswordMessage);
    }
    else {
        formInValidate(cpassword, cpasswordMessage);
    }
};


function formValidate(field, Message) {
    field.classList.add('isValidate');
    field.classList.remove('isInValidate');
    Message.classList.add('success-msg');
    Message.classList.remove('fail-msg');
    Message.innerText = 'weldone';
}

function formInValidate(field, Message) {
    field.classList.remove('isValidate');
    field.classList.add('isInValidate');
    Message.classList.remove('success-msg');
    Message.classList.add('fail-msg');
    Message.innerText = `plz enter a valid ${field.placeholder}`
}


let userNameField = document.querySelector('#username');
userNameField.addEventListener('keyup', function () {
    checkUser();
})
let emailField = document.querySelector('#email');
emailField.addEventListener('keyup', function () {
    checkEmail();
})
let passwordField = document.querySelector('#password');
passwordField.addEventListener('keyup', function () {
    checkPassword();
})
let confirmPasswordField = document.querySelector('#cpassword');
confirmPasswordField.addEventListener('keyup', function () {
    checkConfirmPassword();
})


function write(message) {

    document.getElementById("message").innerHTML+= message + '<br/>' ;
    }
    function newparagraph() {
        write("");
    }
    //charat
    var character= "HELLO".charAt(2);
      write("The character is as follows:"+ character);
      write("Type of datatype:" + typeof character);
      newparagraph();
    var text = "HELLO WORLD";
    document.getElementById("demo").innerHTML = "The character code is:"+ text.charCodeAt(0);
    
    function myFunction() {
      let text = document.getElementById("demo2").innerHTML;
      document.getElementById("demo2").innerHTML =
      text.toUpperCase();
    }
    const fruits = ["Banana", "Orange", "Apple"];
    document.getElementById("demo3").innerHTML = fruits;
    
    function myFunctionkartik() {
      fruits.push("Lemon");
      document.getElementById("demo3").innerHTML = fruits;
    }
    const fruitstoday = ["Banana", "Orange", "Apple", "Mango"];
    document.getElementById("demo4").innerHTML = "Original Array:<br>" + fruitstoday;
    
    
      fruitstoday.splice(2, 0, "Lemon", "Kiwi");
      document.getElementById("demo5").innerHTML = "New Array:<br>" + fruitstoday;

      
    