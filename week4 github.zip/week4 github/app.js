var app = new Vue(
                              {
                                  el: '#app',
                                   data: function () {
                                  return {
                                      cart:0,
                                      productName: 'Samsung Mobile',
                                      productModal: 'Galaxy M51',
                                      productPrice: 30000,
                                      currentVarient:0,
                          featureHeading: 'Great Features',
                                      features:['Water Proof' , 'Scretch Free' , 'Eco Freindly'],
                                      varients:[{id:01,color:'Black', image:'assest/images/black.jpg' , inventory:42 },
                                   {id:02,color:'Blue', image:'assest/images/blue.jpg', inventory:0} ]}
                              },
                          
                          computed:
                          {
                          image()
                          {
                          return this.varients[this.currentVarient].image
                          },
                          instock()
                          {
                          return this.varients[this.currentVarient].inventory
                          }
                          },
                          
                          methods:
                          {
                          addToCart(){
                          this.cart=this.cart+1;
                          },
                          
                          updateVarient(ind)
                          {
                          this.currentVarient = ind;
                          
                          }
                          
                          }
                          })