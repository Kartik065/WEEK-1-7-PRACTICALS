

const app = Vue.createApp({
    data() {
        return {
            username: '',
            referrer: '',
            interest: [],
            cart:0,
            product_name: 'PLAY STATION-4',
            product_modal: 'IND-009',
            product_price: 30000,
            inventory: 5,
            image: 'assest/images/ps4.png',
features:['High speed ' , '200GB Spcae  Free' , 'Durable'],
        }
    },

methods:
{
    submitForm() {
        console.log('Username :  ' + this.username);
        console.log('Referrer :  ' + this.referrer);
        console.log('Interest :  ' + this.interest);

    },
addToCart(){
this.cart=this.cart+1;
},



}
})