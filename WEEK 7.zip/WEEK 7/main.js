Vue.component('crickter-details', {
                              data: function () {
                                return {
                                  crickterlist: [
                                    {
                                      first_name: 'Virat', last_name: 'Kohli', age: 35, add: 'Bangalore', role: 'captain'
                                    },
                                    {
                                      first_name: 'Rohit', last_name: 'Sharma', age: 33, add: 'Mumbai', role: 'vice-captain'
                                    },
                                    
                                  ]
                                };
                              },
                              template: '<div><div class="crickter" v-for="crickter in crickterlist"><span>First Name : {{crickter.first_name}}</span>  <span>Last Name : {{crickter.last_name}}</span>  <span>Age : {{crickter.age}}</span>  <span>Address: {{crickter.add}}</span> <span>Role : {{crickter.role}}</span></div></div>'
                            
                            });
                            
                            
                            const CricketerDet = {
                              data: function () {
                                return {
                                  crickterlist: [
                                    {
                                      first_name: 'Virat', last_name: 'Kohli', age: 35, add: 'Bangalore', role: 'captain'
                                    },
                                    {
                                      first_name: 'Rohit', last_name: 'Sharma', age: 33, add: 'Mumbai', role: 'vice-captain'
                                    },
                                   
                                  ]
                                };
                              },
                              template: '<div><div class="crickter" v-for="crickter in crickterlist"><span>First Name : {{crickter.first_name}}</span>  <span>Last Name : {{crickter.last_name}}</span>  <span>Age : {{crickter.age}}</span>  <span>Address: {{crickter.add}}</span> <span>Role : {{crickter.role}}</span></div></div>'
                            
                            };
                            
                            var app = new Vue(
                              {
                                el: '#app',
                                components: {
                                  'crick-det': CricketerDet
                                },
                                data: {
                                  heading: "Indian Cricketer's  Details",
                                },
                              });
                            
                            var app1 = new Vue(
                              {
                                el: '#app1',
                                data: {
                                  heading: "Indian Cricketer's  Details",
                                },
                              });


                              
                              Vue.component('coupan',
  {
    template: '<div><input placeholder="Enter Coupan Code"><button  @click="onCoupanApplied">Apply Coupan</button><div>',

    methods:
    {
      onCoupanApplied() {
        this.$emit('applied');
      }
    }
  });

var coupan = new Vue(
  {
    el: '#app2',


    data:
    {
tittle : 'Enter Your Coupan Here',
      coupanApplied: false
    },
    methods:
    {
      onCoupanApplied() {
        this.coupanApplied = true;
      }
    }
  }
);
const studentDetails = [
  {
    name: "JAMES",
    percentage: "85%",
    course: 'BTECH'

  }
  ,
  {
    name: "GLOVE",
    percentage: "65%",
    course: 'CS'

  },
  {
    name: "Tarun",
    percentage: "78%",
    course: 'BBA'

  },
  {
    name: "JAYDEN",
    percentage: "52%",
    course: 'MCA'

  },
  {
    name: "Gaurav",
    percentage: "91%",
    course: 'CYCOLOGY'

  },
  

];


Vue.component('student-record', {

  props: ['name', 'percentage', 'course'],

  data: function () {
    return {
      isWarn: false,
    }
  },

  methods: {
    warn: function () {
      this.isWarn = !this.isWarn;
      console.log(this.isWarn);
    }
  },

  template: `<div class="d-flex"><div class="d-inline" v-bind:class="{ 'warned': isWarn }">
    <h3> Name: {{ name }}</h3>
    <p>Percentage : {{ percentage }}</p>
    <p>Course : {{ course }}</p>
    <button v-on:click="warn">Warn</button>
  </div></div>`

});
var app = new Vue(
  {
    el: '#app3',
    data: {
      heading: "Student  Details",
      students: studentDetails
    },

  });
  Vue.component("Card", {
    template: `<div class="cardcontainer">
      <div class="card">
        <slot></slot>
        <div id="card-header">
          <slot name="header"></slot>
        </div>
        <div id="card-main">
          <slot name="main"></slot>
        </div>
        <div id="card-footer">
          <slot name="footer"></slot>
        </div>
      </div>
    </div>`
  });
  new Vue({
    el: "#app5",
  });
  
                        
                            